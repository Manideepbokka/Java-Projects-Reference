import java.net.*;
import java.io.*;
class DatagramClient
{
public static void main(String args[])throws Exception
{
try
{
DatagramSocket ds=new DatagramSocket(666);
byte b[]=new byte[100];
DatagramPacket dp=new DatagramPacket(b,b.length);
ds.receive(dp);//Data send to take in DataPacket
String data =new String(dp.getData());
System.out.println("The data recieved from server is:"+data);
ds.close();//close the Datagram socket
}
catch(Exception e){e.printStackTrace();}
}
}
