import java.awt.FlowLayout;  
import javax.swing.*;  
class JScrollExample extends JFrame
{
JTextArea jta;
JScrollPane jsp;
JScrollExample()
{

jta = new JTextArea(10,20);
jsp= new JScrollPane(jta,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
setLayout(new FlowLayout());
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
add(jsp);
setSize(400,400);
setLocationRelativeTo(null);
setVisible(true);
}
public static void main(String args[])
{
new JScrollExample();
}
}
