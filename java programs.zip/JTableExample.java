import javax.swing.*;
public class JTableExample
{
JFrame f;
JTableExample()
{
f=new JFrame();
String data[][]={ {"510","Amit","670000"},
                           {"520","Jai","780000"},
                           {"530","Sachin","700000"}};
String column[]={"ID","NAME","SALARY"};
JTable jt = new JTable(data,column);
jt.setBounds(30,40,200,300);
JScrollPane sp = new JScrollPane(jt);
f.add(sp);
f.setSize(300,400);
f.setVisible(true);
}
public static void main(String args[])
{
new JTableExample();
}
}
