class ArthematicException
{
  public static void main(String[] args)
  {
    try
    {
      int a=10;
      int b=a/0;
      System.out.println("division:"+b);
    }
    catch (Exception e)
     {
      System.out.println("Generated Exception:"+e);
    }
  }
}
