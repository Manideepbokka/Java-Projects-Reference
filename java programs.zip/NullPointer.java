public class NullPointer{
   public static void main(String[] args) {
      Object ref = null;
      ref.toString(); // this will throw a NullPointerException
   }
}