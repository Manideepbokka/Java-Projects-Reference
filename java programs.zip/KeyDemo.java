import java.awt.*;
import java.awt.event.*;
import java.applet.*;
public class KeyDemo extends Applet implements KeyListener
{
String msg="";
public void init()
{
addKeyListener(this);
}
public void keyPressed(KeyEvent e)
{
showStatus("Key pressed");
}
public void keyReleased(KeyEvent e)
{
showStatus("Key released");
}
public void keyTyped(KeyEvent e)
{
showStatus("Key Typed");
msg=msg+e.getKeyChar();
repaint();
}
public void paint(Graphics g)
{
g.drawString(msg,50,50);
}
}


