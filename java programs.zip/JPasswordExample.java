import javax.swing.*;
public class JPasswordExample
{
JPasswordExample()
{
JFrame f = new JFrame();
JPasswordField value=new JPasswordField();
JLabel l1= new JLabel("Password");
l1.setBounds(20,100,80,30);
value.setBounds(110,100,100,30);
f.add(l1);
f.add(value);
f.setSize(300,300);
f.setLayout(null);
f.setVisible(true);
}
public static void main(String arg[])
{
new JPasswordExample();
}
}
