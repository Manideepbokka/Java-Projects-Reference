public class ClassNotFound { 
      
    public static void main(String args[]) { 
        try 
        { 
            Class.forName("Manoj"); 
        } 
        catch (ClassNotFoundException ex) 
        { 
            ex.printStackTrace(); 
        } 
    } 
} 