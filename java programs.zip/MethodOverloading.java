class Addition
{
  void add(int a,int b)
  {
    int c;
    c=a+b;
    System.out.println("Sum:"+c);
  }
  void add(int a,int b,int c)
  {
    int d=a+b+c;
    System.out.println("Sum:"+d);
  }
  void add(double a,double b)
  {
    double c=a+b;
    System.out.println("Sum:"+c);
  }
}
class MethodOverloading
{
  public static void main(String[] args)
  {
    Addition a = new Addition();
    a.add(1,2,3);
    a.add(20,20);
    a.add(1.56,2.98);
  }
}
