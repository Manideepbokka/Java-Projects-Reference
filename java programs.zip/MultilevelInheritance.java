class A
{
  void method1()
  {
    System.out.println("Method 1 in class A");
  }
}
class B extends A
{
  void method2()
  {
    System.out.println("Method 2 in class B");
  }
}
class C extends B
{
  void method3()
  {
    System.out.println("Method 3 in class C");
  }
}
class MultilevelInheritance
{
  public static void main(String[] args)
   {
     C obj = new C();
     obj.method1();
     obj.method2();
     obj.method3();
  }
}
