import java.awt.*;
import java.awt.event.*; 
import java.applet.*;
public class MouseDemo extends Applet implements MouseListener,MouseMotionListener
{
int x,y,w,h; 
public void init()
{
addMouseListener(this); 
addMouseMotionListener(this);
}
public void mouseClicked(MouseEvent e)
{ 
x = e.getX();
y = e.getY(); 
repaint();
}
public void mouseEntered(MouseEvent e)
{ 
x = e.getX();
y = e.getY(); 
repaint();
}
public void mouseExited(MouseEvent e){ 
x = e.getX();
y = e.getY(); 
repaint();
}
public void mousePressed(MouseEvent e){ 
x = e.getX();
y = e.getY(); 
repaint();
}
public void mouseReleased(MouseEvent e){ 
w = e.getX();
h = e.getY(); 
repaint();
}
public void mouseDragged(MouseEvent e)
{
w = e.getX();
h = e.getY(); 
repaint();
}
public void mouseMoved(MouseEvent e){ 
showStatus("Mouse-Active");
}
public void paint(Graphics g){ 
g.drawRect(x,y,w,h);
}
}