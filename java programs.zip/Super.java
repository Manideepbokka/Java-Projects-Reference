class Person
{
  int id;
  String name;
  Person(int id,String name)
  {
    this.id=id;
    this.name=name;
  }
}
class Emp extends Person
{
  float Salary;
  Emp(int id,String name,float Salary)
  {
    super(id,name);
    this.Salary=Salary;
  }
  void display()
  {
    System.out.println(id+" "+name+" "+Salary);
  }
}
class Super
{
  public static void main(String[] args)
   {
    Emp e1 = new Emp(510,"Manoj",45000);
    e1.display();
  }
}
