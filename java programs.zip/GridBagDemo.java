import java.awt.*;
import javax.swing.*;
public class GridBagDemo { 
JFrame f; 
GridBagDemo(){
f=new JFrame();
GridBagLayout gbl = new GridBagLayout(); 
f.setLayout(gbl);
GridBagConstraints gbc = new GridBagConstraints(); 
gbc.fill = GridBagConstraints.HORIZONTAL;
gbc.gridx = 0;
gbc.gridy = 0;
JButton b1=new JButton("Button 1"); 
f.add(b1,gbc);gbc.gridx = 1;
gbc.gridy = 0;
JButton b2=new JButton("Button 2"); 
f.add(b2,gbc);
gbc.ipady = 20;//gives y-padding
gbc.gridx = 0;
gbc.gridy = 1;
JButton b3=new JButton("Button 3"); 
f.add(b3,gbc);
gbc.gridx = 1;
gbc.gridy = 1;
JButton b4=new JButton("Button 4"); 
f.add(b4,gbc);gbc.gridx = 0;
gbc.gridy = 2;
gbc.gridwidth = 2;//No.of Horizontal Cells Taken 
JButton b5=new JButton("Button 5"); 
f.add(b5,gbc);
f.setSize(300,300); 
f.setVisible(true);
}
public static void main(String[] args) 
{ 
new GridBagDemo();
}
}