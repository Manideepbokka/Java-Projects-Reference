class NegativeArraySize
{
  public static void main(String[] args)
  {
    try
    {
      int arr[]=new int[-2];
      System.out.println("First Element:"+arr[0]);
    }
    catch (Exception e)
     {
      System.out.println("Generated Exception:"+e);
    }
    System.out.println("After try block");
  }

}
