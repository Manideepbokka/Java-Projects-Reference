import java.lang.*;
import java.util.*;
interface Calculate
{
public void multiply(int a,int b);
public void division(int a,int b);
}
class A implements Calculate
{
public  void multiply(int a,int b)
{
System.out.println(a*b);
}
public  void division(int a,int b)
{
System.out.println(a/b);
}
}
class Interface
{
public static void main(String args[])
{
A a = new A();
a.multiply(4,2);
a.division(4,2);
}
}
