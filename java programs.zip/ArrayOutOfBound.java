class ArrayOutOfBound
{
  public static void main(String[] args)
  {
    try
     {
    int arr[]={1,2,3,4,5,6,7};
    for (int i=0; i<=10;i++ ) {
        System.out.println("Array elemet:"+arr[10]);
    }
  }
  catch (Exception e)
  {
    System.out.println("Generated Exception :"+e);
  }
  }
}
