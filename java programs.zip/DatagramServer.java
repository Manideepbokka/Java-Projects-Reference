import java.net.*;
import java.io.*;
public class DatagramServer
{
public static void main(String args[]) throws Exception
{
while(true)
{
try
{
String str ="Hai can you here me?";
DatagramSocket ds=new DatagramSocket(999);
byte b[]=str.getBytes();
DatagramPacket dp=new DatagramPacket(b,b.length,InetAddress.getLocalHost(),666);
ds.send(dp);
ds.close();
}
catch(Exception e){e.printStackTrace();}
}
}
}

